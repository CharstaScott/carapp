using Microsoft.AspNetCore.Mvc;

namespace SimpleWebApi.Controllers {

    [Route("api/[Controller]")]
    public class CarController : ControllerBase {

        [HttpGet("{Car}")]
        public string Get(string Car) {
            return Car;
        }
    }
}